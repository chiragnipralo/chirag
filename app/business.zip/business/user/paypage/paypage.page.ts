import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paypage',
  templateUrl: './paypage.page.html',
  styleUrls: ['./paypage.page.scss'],
})
export class PaypagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
