import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raise-fund',
  templateUrl: './raise-fund.page.html',
  styleUrls: ['./raise-fund.page.scss'],
})
export class RaiseFundPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
