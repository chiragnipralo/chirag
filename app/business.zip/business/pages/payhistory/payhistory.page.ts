import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payhistory',
  templateUrl: './payhistory.page.html',
  styleUrls: ['./payhistory.page.scss'],
})
export class PayhistoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
