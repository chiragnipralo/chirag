import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-chat',
  templateUrl: './community-chat.page.html',
  styleUrls: ['./community-chat.page.scss'],
})
export class CommunityChatPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
